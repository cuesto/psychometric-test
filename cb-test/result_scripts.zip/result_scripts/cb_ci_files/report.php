<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="css/report.css" rel="stylesheet" type="text/css" />
</head>

<body>
<div id="rept_wrapper">
  <div class="horizontal_margin">
    <div id="header"> <span class="lftfloated">
      <h2 class="colorbase bold">CONFIDENTIAL</h2>
      </span> <span class="rgtfloated">
      <h2 class="colorbase1 bold">Ref. No.: ASDF89542</h2>
      </span> </div>
  </div>
  <!--header horizontal marign ends -->
  <div class="clear"></div>
  <div id="ind_cntnt">
    <div id="candidate_info">
      <h4 class="colorbase3 normal line_spacer"> For<br />
        Mr. Guruprasad Kotyan<br />
        gpkotyan@gmail.com<br />
        +91 990-109-8717 </h4>
    </div>
    <div class="clear"></div>
    <div id="banner">
      <div id="imgclip"><img src="images/report/img1.png"/></div>
    </div>
    <div class="clear"></div>
    <div id="report_info">
      <h4 class="colorbase3 normal line_spacer"> Report Prepared On<br />
        June 14, 2012 </h4>
    </div>
  </div>
  <!--footer starts -->
  <div class="horizontal_margin">
    <div id="btm_logowrap"><img src="images/report/reprtcb-logo.png" width="190" height="67" /></div>
    <div id="gen_footer">
      <h1 class="colorbase center normal"> <strong>contactus@careerbreeder.com</strong> &nbsp;|&nbsp;+91 805 55 55 248&nbsp;|&nbsp;www.careerbreeder.com</h1>
      <h1 class="colorbase lftfloated normal center">Career Breeder is an initiative of Oprotech Technologies Pvt Ltd. Copyright © 2012. All rights reserved. </h1>
    </div>
  </div>
</div>
<!--repot_wrapper ends here -->
</body>
</html>
