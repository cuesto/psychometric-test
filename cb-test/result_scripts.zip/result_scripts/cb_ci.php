<?php
function cb_ci($ref_no) {
        include('wp-content/plugins/dompdf/dompdf_config.inc.php');
    //Initialize
    for($i=0;$i<5;$i++){
        $res[$i]['a']=0;
        $res[$i]['b']=0;
    }
    
    //result array
    $answers = Array(
        0 => Array (
            1 => Array ('answer' => 'C', 'weight' => '3'),
            2 => Array ('answer' => 'P', 'weight' => '2'),
            3 => Array ('answer' => 'P', 'weight' => '3'),
            4 => Array ('answer' => 'P', 'weight' => '2'),
            5 => Array ('answer' => 'C', 'weight' => '3'),
            6 => Array ('answer' => 'P', 'weight' => '3'),
            7 => Array ('answer' => 'C', 'weight' => '2'),
            8 => Array ('answer' => 'P', 'weight' => '3'),
            9 => Array ('answer' => 'P', 'weight' => '3'),
            10 => Array ('answer' => 'P', 'weight' => '3'),
            11 => Array ('answer' => 'P', 'weight' => '3'),
            12 => Array ('answer' => 'P', 'weight' => '2'),
            13 => Array ('answer' => 'C', 'weight' => '5'),
            14 => Array ('answer' => 'C', 'weight' => '2'),
            15 => Array ('answer' => 'P', 'weight' => '5'),
            16 => Array ('answer' => 'C', 'weight' => '3'),
            17 => Array ('answer' => 'C', 'weight' => '3'),
            18 => Array ('answer' => 'P', 'weight' => '5'),
            19 => Array ('answer' => 'C', 'weight' => '2'),
            20 => Array ('answer' => 'C', 'weight' => '3'),
        ),
        1 => Array (
            1 => Array ('answer' => 'D', 'weight' => '3'),
            2 => Array ('answer' => 'M', 'weight' => '2'),
            3 => Array ('answer' => 'D', 'weight' => '3'),
            4 => Array ('answer' => 'D', 'weight' => '2'),
            5 => Array ('answer' => 'D', 'weight' => '3'),
            6 => Array ('answer' => 'D', 'weight' => '3'),
            7 => Array ('answer' => 'D', 'weight' => '2'),
            8 => Array ('answer' => 'D', 'weight' => '3'),
            9 => Array ('answer' => 'D', 'weight' => '3'),
            10 => Array ('answer' => 'M', 'weight' => '3'),
            11 => Array ('answer' => 'D', 'weight' => '3'),
            12 => Array ('answer' => 'D', 'weight' => '2'),
            13 => Array ('answer' => 'D', 'weight' => '5'),
            14 => Array ('answer' => 'M', 'weight' => '2'),
            15 => Array ('answer' => 'D', 'weight' => '5'),
            16 => Array ('answer' => 'D', 'weight' => '3'),
            17 => Array ('answer' => 'D', 'weight' => '3'),
            18 => Array ('answer' => 'D', 'weight' => '5'),
            19 => Array ('answer' => 'D', 'weight' => '2'),
            20 => Array ('answer' => 'D', 'weight' => '3'),
        ),
        2 => Array (
            1 => Array ('answer' => 'E', 'weight' => '3'),
            2 => Array ('answer' => 'E', 'weight' => '2'),
            3 => Array ('answer' => 'E', 'weight' => '3'),
            4 => Array ('answer' => 'I', 'weight' => '2'),
            5 => Array ('answer' => 'E', 'weight' => '3'),
            6 => Array ('answer' => 'E', 'weight' => '3'),
            7 => Array ('answer' => 'E', 'weight' => '2'),
            8 => Array ('answer' => 'E', 'weight' => '3'),
            9 => Array ('answer' => 'E', 'weight' => '3'),
            10 => Array ('answer' => 'E', 'weight' => '3'),
            11 => Array ('answer' => 'E', 'weight' => '3'),
            12 => Array ('answer' => 'E', 'weight' => '2'),
            13 => Array ('answer' => 'E', 'weight' => '5'),
            14 => Array ('answer' => 'E', 'weight' => '2'),
            15 => Array ('answer' => 'I', 'weight' => '5'),
            16 => Array ('answer' => 'I', 'weight' => '3'),
            17 => Array ('answer' => 'E', 'weight' => '3'),
            18 => Array ('answer' => 'E', 'weight' => '5'),
            19 => Array ('answer' => 'I', 'weight' => '2'),
            20 => Array ('answer' => 'E', 'weight' => '3'),
        ),
        3 => Array (
            1 => Array ('answer' => 'Q', 'weight' => '3'),
            2 => Array ('answer' => 'S', 'weight' => '2'),
            3 => Array ('answer' => 'S', 'weight' => '3'),
            4 => Array ('answer' => 'Q', 'weight' => '2'),
            5 => Array ('answer' => 'S', 'weight' => '3'),
            6 => Array ('answer' => 'S', 'weight' => '3'),
            7 => Array ('answer' => 'Q', 'weight' => '2'),
            8 => Array ('answer' => 'S', 'weight' => '3'),
            9 => Array ('answer' => 'Q', 'weight' => '3'),
            10 => Array ('answer' => 'S', 'weight' => '3'),
            11 => Array ('answer' => 'Q', 'weight' => '3'),
            12 => Array ('answer' => 'S', 'weight' => '2'),
            13 => Array ('answer' => 'S', 'weight' => '5'),
            14 => Array ('answer' => 'Q', 'weight' => '2'),
        ),
        4 => Array (
            1 => Array ('answer' => 'R', 'weight' => '3'),
            2 => Array ('answer' => 'R', 'weight' => '2'),
            3 => Array ('answer' => 'R', 'weight' => '3'),
            4 => Array ('answer' => 'R', 'weight' => '2'),
            5 => Array ('answer' => 'R', 'weight' => '3'),
            6 => Array ('answer' => 'R', 'weight' => '3'),
            7 => Array ('answer' => 'R', 'weight' => '2'),
            8 => Array ('answer' => 'F', 'weight' => '3'),
            9 => Array ('answer' => 'F', 'weight' => '3'),
            10 => Array ('answer' => 'R', 'weight' => '3'),
            11 => Array ('answer' => 'R', 'weight' => '3'),
            12 => Array ('answer' => 'R', 'weight' => '2'),
            13 => Array ('answer' => 'R', 'weight' => '5'),
            14 => Array ('answer' => 'F', 'weight' => '2'),
            15 => Array ('answer' => 'F', 'weight' => '5'),
            16 => Array ('answer' => 'R', 'weight' => '3'),
            17 => Array ('answer' => 'R', 'weight' => '3'),
            18 => Array ('answer' => 'R', 'weight' => '5'),
            19 => Array ('answer' => 'R', 'weight' => '2'),
            20 => Array ('answer' => 'R', 'weight' => '3'),
        ),
    );
    
    //fetch user's answers and store in an array
    global $wpdb;
    $table_name = $wpdb->prefix."cb_result_master";
    $answersTicked = $wpdb->get_results("SELECT * FROM $table_name WHERE ref_no =$ref_no");
    $result = json_decode($answersTicked[0]->result);
    //map answers and give marks;
    $marksObtained = 0;
    for($i=0;$i<sizeof($result);$i++)
    {
        //find the question number
        $question_id = $result[$i]->question_id;
        $table_name = $wpdb->prefix."cb_questions";
        $question_no = $wpdb->get_results("SELECT * FROM $table_name WHERE question_id = $question_id");
        $section_id = $question_no[0]->section_id; 
        $question_no = $question_no[0]->question_no;

        //fetch option number
        $option_id = $result[$i]->option_id;
        $table_name = $wpdb->prefix."cb_option";
        $option_no = $wpdb->get_results("SELECT * FROM $table_name WHERE option_id = $option_id");
        $option_no = $option_no[0]->question_no;
        
        //get section number
        $table_name = $wpdb->prefix."cb_section";
        $section_no = $wpdb->get_results("SELECT * FROM $table_name WHERE section_id = $section_id");
        $section_no = $section_no[0]->section_no; 
        
        
        /**
         * Separate Question Index and Section Index from the given question number
         * Section Index is zero index but question index is 1 index
         */
        if($question_no<=70)
        {
            $section_index = $question_no%5-1;
            if($section_index==-1)
            {
                $section_index=4;
                $question_index = ($question_no-$question_no%5)/5;
            } else
                $question_index = ($question_no-$question_no%5)/5+1;
        } else if($question_no>= 71){
            $question_no -= 70;
            $section_index = $question_no%4-1;
            if($section_index==-1)
            {
                $section_index=4;
                $question_index = ($question_no-$question_no%4)/4;
            } else
                $question_index = ($question_no-$question_no%4)/4+1;            
            $question_index += 14;
        } else {
            echo "Something went wrong. Too many questions to handle";
        }
        
//        echo $question_index.",".$section_index
        
        if($option_no == 0)
        {
            if(cb_test_helper123($answers[$section_index][$question_index]['answer'])==0)
            {
                $res[$section_index]['a']++;
            }else if(cb_test_helper123($answers[$section_index][$question_index]['answer'])==1)
            {
                $res[$section_index]['b']++;
            }else 
            {
                print_r($answers[$section_index][$question_index]);
                echo "Something is wrong $section_no , $question_no,";
            }
        } else if($option_no == 1) {
            if(cb_test_helper123($answers[$section_index][$question_index]['answer'])==1)
            {
                $res[$section_index]['a']++;
            }else if(cb_test_helper123($answers[$section_index][$question_index]['answer'])==0)
            {
                $res[$section_index]['b']++;
            }else 
            {
                print_r($answers[$section_index][$question_index]);
                echo "Something is wrong $section_no , $question_no,";
            }
        } else {
            echo "Some error occured in Question Number $i,$option_no,$option_id,$section_no";
        }
        
    }

    $code = Array();
    
    if($res[0]['a']>$res[0]['b'])
        $code[] = "P";
    else
        $code[] = "C";
    
    if($res[1]['a']>$res[1]['b'])
        $code[] = "D";
    else
        $code[] = "M";
    
    if($res[2]['a']>$res[2]['b'])
        $code[] = "E";
    else
        $code[] = "I";
    
    if($res[3]['a']>$res[3]['b'])
        $code[] = "Q";
    else
        $code[] = "S";
    
    if($res[4]['a']>$res[4]['b'])
        $code[] = "R";
    else
        $code[] = "F";
    $compressedCode = implode("",$code);
    $result = $res; 
    
    $res ='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
            <html xmlns="http://www.w3.org/1999/xhtml">
            <head>
            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
            <title>Untitled Document</title>
            <link href="wp-content/plugins/cb-test/result_scripts/cb_ci_files/report.css" rel="stylesheet" type="text/css" />';
    $res .= '<style type="text/css">
        .description_page { page-break-before: always; }
        .graph { page-break-before: always; }
        .last_page { page-break-before: always; }
        .sugg1 { page-break-before: always; }
        .sugg2 { page-break-before: always; }
        .car1 { page-break-before: always; }
        </style>';
    
    $user_info = get_userdata($answersTicked[0]->uid);
    
    //front page
    $res .= '</head><body>
        <div class="rept_wrapper">
          <div class="horizontal_margin">
            <div class="header"> 
            <table width="110%" border="0" style="margin:0px" >
  <tr>
    <td rowspan="2" align="left" style=" vertical-align:top"><div class="bill_logo" style="float:left;"><img src="wp-content/plugins/cb-test/result_scripts/cb_ci_images/bill_logo.jpg" width="240" height="80" /></div></td>
    <td>&nbsp;</td>
    <td align="center" style=" vertical-align:baseline"> <div class="invoice">
				  <h2 class="colorbase1 bold" style=""><span class="rgtfloated">Ref. No.:'.$ref_no.'</span></h2>
				 	
					
				  </div>
</td>
  </tr>
  <tr>
    
    <td>&nbsp;</td>
    <td align="center"style=" vertical-align:top"> <img src="wp-content/plugins/cb-test/result_scripts/cb_ci_images/barcode.png" width="200" height="63" />	</td>
  </tr>
</table>

				<div class="invoice_containor" style="float:left;">
				 
				 				</div>
			</div>
              
               
          </div>
          <!--header horizontal marign ends -->
          <div class="clear"></div>
          <div class="ind_cntnt">
            <div id="candidate_info">
              <h4 class="colorbase3 normal line_spacer"><span style="font-size:22px;color:#bc2781; margin-left:-50px"> For,</span><br />
                ';
               $res.= '<span style="font-size:18px;color:red">'; 
               
               if(isset($user_info->display_name))
                    $res.= $user_info->display_name.'</span><br />';
                else if(isset($user_info->user_nicename))
                    $res.=  $user_info->user_nicename.'<br />';
                else if(isset($user_info->nickname))
                    $res.=  $user_info->nickname.'<br />';
                else if(isset($user_info->name))
                    $res.=  $user_info->name.'<br />';
                else if(isset($user_info->user_email))
                    $res.=  $user_info->user_email.'<br />';
                
                if(isset($user_info->contact_number))    
                    $res.= $user_info->contact_number.'</h4><br/>
            </div>
            <div class="clear"></div>
            <div id="banner">
              <div id="imgclip"><img src="wp-content/plugins/cb-test/result_scripts/cb_ci_images/ring.png"  />';
ob_start();
if(userphoto_exists($user_info->id))
   userphoto($user_info->id,"","",array('height'=>88,'width'=>78));
else
    $res.= get_avatar(1, 96);
$res.= str_replace("http://careerbreeder.com/","",ob_get_clean());



$res.= '</div>
            </div>
            <div class="clear"></div>
            <div id="report_info">
              <h4 class="colorbase3 normal line_spacer"> Report Prepared On<br />
                '.$answersTicked[0]->time.' </h4>
            </div>
          </div>
          
           <div class="clear"></div><br /><br /><br />
            <div id="middle_content" style="boarder:1px solid #bc2781">
            	<table width="100%" border="0" >
  			<tr>
  			  <td width="57%" rowspan="2" align="center" style=" vertical-align:middle"><img src="wp-content/plugins/cb-test/result_scripts/cb_ci_images/url.png" width="200" height="82"  /></td>
    <td width="43%">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" style=" vertical-align:middle"><table width="100%" border="0" ><tr> <td align="left"><td> <img src="wp-content/plugins/cb-test/result_scripts/cb_ci_images/rajesh.png" height="73" width="146"/></td> </tr><tr><td align="center">  </td><td> Rajesh Chandra Pandey (Career Counsellor)</td></tr></table></td>
  </tr>
</table>
            </div>
          
          <!--footer starts -->
          <div class="clear"></div>
          <div class="horizontal_margin">
          <img src="wp-content/plugins/cb-test/result_scripts/cb_ci_images/footerbg_pdf.png" width="600" height="242"  />
        </div>
        <!--report_wrapper ends here --> ';
        
    //header and footer
    $header = '<div class="horizontal_margin">
            <div class="header">
                <span class="lftfloated"><img src="wp-content/plugins/cb-test/result_scripts/cb_ci_images/reprtcb-logoinner.png" width="172" height="58" /></span>
        	   <span class="rgtfloated"><img src="wp-content/plugins/cb-test/result_scripts/cb_ci_images/indicator-innertop.png" width="133" height="41" /></span>
                <span class="rgtfloated" style="margin-right:20px"><span class="colorbase1 bold">Ref. No.:'.$ref_no.'</span></span>
            </div>
            </div><!--header horizontal marign ends -->
            <div class="clear"></div>';
    
    $footer = '<div class="gen_footer">
                   	 <h4 class="colorbase center normal"> <strong>contactus@careerbreeder.com</strong> &nbsp;|&nbsp;+91 974 308 3301&nbsp;|&nbsp;www.careerbreeder.com</h4>
                     <h4 class="colorbase normal center">Career Breeder is an initiative of Oprotech Technologies Pvt Ltd. Copyright &copy; 2012. All rights reserved. </h4>
                </div>';
        
    //page 2 index page
    
    
    //page 3 content
    $description_page = "<div class=\"description_page rept_wrapper\">";
    $description_page .= $header;
    $description_page .= "<h2>With this report, you can:</h2>
            <ul>
        <li>Identify job groups or broad occupational categories suitable for you</li>
        <li>Choose a specific job or career</li>
        <li>Select a college major or course of study</li>
        <li>Identify strengths and potential weaknesses in your personality</li>
        <li>Increase your job satisfaction</li>
        <li>Make a career transition or shift</li>
        <li>Plan your next steps in career development strategy</li></ul>";

    $description_page .= "<br/><br/><h2>Your type description is <strong>$compressedCode</strong></h2>
            <br/><h3>To lead a satisfying professional life, you should have a balance in all dimensions of your personality. Every individual has certain characteristics that determine the role of each dimension in your personality. Scarcity or deficiency with a difference of less then 20% is considered good.</h3>
            <div>For example:<br/> 1) 65% extrovert and 35% introvert is considered as good.<br/>2) 35% Extrovert and 65% Introvert is also considered as good.<br/> 3) 10% Extrovert and 90% Introvert needs little improvement.</div>";
    
    $description_page .= $footer;
    $description_page.="</div>";
    
    //graph
   	include("wp-content/plugins/cb-test/result_scripts/libchart/libchart/classes/libchart.php");
    
    
    //Thinking Process
    	$chart = new PieChart();
        $chart->getPlot()->getPalette()->setPieColor(array(
        		new Color(246, 147, 96),
        		new Color(152, 54, 73)
          ));
    	$dataSet = new XYDataSet();
        if($result[0]['a']>$result[0]['b'])
        {
        	$dataSet->addPoint(new Point("Practical Thinker", $result[0]['a']));
        	$dataSet->addPoint(new Point("Creative Thinker", $result[0]['b']));
    	} else {
        	$dataSet->addPoint(new Point("Creative Thinker", $result[0]['b']));    	   
        	$dataSet->addPoint(new Point("Practical Thinker", $result[0]['a']));
    	}
        $chart->setDataSet($dataSet);
    	$chart->setTitle("Thinking Process");
    	$chart->render("tmp/chart1.png");
        
     //Behavior Pattern
    	$chart = new PieChart();
        $chart->getPlot()->getPalette()->setPieColor(array(
        		new Color(246, 147, 96),
        		new Color(152, 54, 73)
          ));
    	$dataSet = new XYDataSet();
        if($result[1]['a']>$result[1]['b'])
        {
        	$dataSet->addPoint(new Point("Determined", $result[1]['a']));
        	$dataSet->addPoint(new Point("Moody", $result[1]['b']));
        } else {
        	$dataSet->addPoint(new Point("Moody", $result[1]['b']));
        	$dataSet->addPoint(new Point("Determined", $result[1]['a']));            
        }
    	$chart->setDataSet($dataSet);
    	$chart->setTitle("Behavior Pattern");
    	$chart->render("tmp/chart2.png");
     
     //Social Expression
    	$chart = new PieChart();
        $chart->getPlot()->getPalette()->setPieColor(array(
        		new Color(246, 147, 96),
        		new Color(152, 54, 73)
          ));
    	$dataSet = new XYDataSet();
        if($result[2]['a']>$result[2]['b'])
        {
        	$dataSet->addPoint(new Point("Extrovert", $result[2]['a']));
        	$dataSet->addPoint(new Point("Introvert", $result[2]['b']));
        } else {
        	$dataSet->addPoint(new Point("Introvert", $result[2]['b']));            
        	$dataSet->addPoint(new Point("Extrovert", $result[2]['a']));
        }
    	$chart->setDataSet($dataSet);
    	$chart->setTitle("Social Expression");
    	$chart->render("tmp/chart3.png");
     
	
     //Decision Making HabitBehavior Pattern
    	$chart = new PieChart();
        $chart->getPlot()->getPalette()->setPieColor(array(
        		new Color(246, 147, 96),
        		new Color(152, 54, 73)
          ));
    	$dataSet = new XYDataSet();
        if($result[3]['a']>$result[3]['b'])
        {
        	$dataSet->addPoint(new Point("Quick", $result[3]['a']));
        	$dataSet->addPoint(new Point("Security minded", $result[3]['b']));
         } else {
        	$dataSet->addPoint(new Point("Security minded", $result[3]['b']));            
        	$dataSet->addPoint(new Point("Quick", $result[3]['a']));
         }
    	$chart->setDataSet($dataSet);
    	$chart->setTitle("Decision Making Habit");
    	$chart->render("tmp/chart4.png");
        
        
     //Work Attitude
    	$chart = new PieChart();
        $chart->getPlot()->getPalette()->setPieColor(array(
        		new Color(246, 147, 96),
        		new Color(152, 54, 73)
          ));
    	$dataSet = new XYDataSet();
        if($result[3]['a']>$result[3]['b'])
        {
        	$dataSet->addPoint(new Point("Rule Bound", $result[4]['a']));
        	$dataSet->addPoint(new Point("Flexible", $result[4]['b']));
         } else {
        	$dataSet->addPoint(new Point("Flexible", $result[4]['b']));            
        	$dataSet->addPoint(new Point("Rule Bound", $result[4]['a']));
         }
    	$chart->setDataSet($dataSet);
    	$chart->setTitle("Work Attitude");
    	$chart->render("tmp/chart5.png");
     
     $graphs = '<div class="graph">';
     $graphs .= $header;
     $graphs .= '<div class="graphs">';
         $graphs .= '<img src="tmp/chart1.png"/>';
         $graphs .= '<img src="tmp/chart2.png"/>';
         $graphs .= '<img src="tmp/chart3.png"/>';
         $graphs .= "</div>".$footer;
     $graphs .= '</div>';

     $graphs .= '<div class="graph">';
     $graphs .= $header;
     $graphs .= '<div class="graphs">';
         $graphs .= '<img src="tmp/chart4.png"/>';
         $graphs .= '<img src="tmp/chart5.png"/>';
         $graphs .= "</div>".$footer;
     $graphs .= '</div>';
     
     
     
        for($i=0;$i<5;$i++)
        {
            $ratio[$i] = ($result[$i]['a']/($result[$i]['a']+$result[$i]['b']));
            if($ratio[$i]>0.5) $ratio[$i]=1-$ratio[$i];
        }
        asort($ratio);
        $ratio_temp = $ratio;
        $i=0;
        
        
     //Characteristics and Suggestions page 1
     $sugg ="";
     $sugg .= '<div class="sugg1 car1_style rept_wrapper">';
     $sugg .= $header;
     foreach($ratio as $rat)
     {
        $index = array_keys($ratio_temp, $rat);
        if($i>0 && $ratio_temp[$index[0]]>0.35)
            break;        
        $ratio_temp[$index[0]] = 0.5;
        $a = cb_ci_characteristic($code[$index[0]]);
        $i++;

        $sugg.= "<h2 class=\"colorbase1\">".$a['title']."</h2>";
        $sugg.= '<table border="1px" width="100%"><tr><th width="50%">Characteristic</th><th width="50%">Suggestion</th></tr>
        <tr><td>'.$a['characteristic'].'</td><td>'.$a['suggestion'].'</td></tr></table><br/><br/>';
     }
     $sugg .= $footer;
     $sugg .='</div>';
     
     
     
    /**
     * Career Options
     */
    $table_name = $wpdb->prefix."cb_careers";
    $careers = $wpdb->get_results("SELECT * FROM $table_name WHERE code  like '%".$compressedCode."%' ");
     
     $car="";
     $k=1;
     for($j=0;$j<sizeof($careers);$j+=3)
     {
        //career options page $k
         $car .= '<div class="car1 rept_wrapper car1_style">';
         $car .= $header;
         $car .= "<h1 align=\"center\">Suggestive Career Options Page $k</h1>";
         for($i=$j;$i<($j+3);$i++)
         {
            if(!isset($careers[$i]->name)) break;
            $car.= "<h3 class=\"colorbase1\">".$careers[$i]->name." (".$careers[$i]->category.")</h3>";
            $car.= $careers[$i]->description."<br/><br/>";
            $car.= "<strong>Work:</strong>".$careers[$i]->work."<br/><br/>";
            $car.= "<strong>Requirements:</strong>".$careers[$i]->requirements."<br/><br/>";
         }
         $car .= $footer;
         $car .='</div>';
         $k++;
     }


     $k=1;
     for($j=0;$j<sizeof($careers);$j+=7)
     {     
         //career options table page 1
         $car .= '<div class="car1 rept_wrapper">';
         $car .= $header;
         $car .= "<h1 align=\"center\">Suggestive Career Options- Roadmap, Page $k</h1>";
         $car .= "<div class=\"car1_style\"><table border=\"1px\"><tr>
                    <th>Name</th>
                    <th>Title Examples</th>
                    <th>Degrees Associated With This Career</th>
                    <th>Useful Secondary School Subjects</th>
                    <th>Employers</th>
                </tr>";
         for($i=$j;$i<($j+7);$i++)
         {
            if(!isset($careers[$i]->name)) break;
            $car.= "<tr>";
               $car.= "<td>".$careers[$i]->name."</td>";
               $car.= "<td>".$careers[$i]->title_examples."</td>";
               $car.= "<td>".$careers[$i]->degrees_associated_with_this_career."</td>";
               $car.= "<td>".$careers[$i]->useful_secondary_school_subjects."</td>";
               $car.= "<td>".$careers[$i]->employers."</td>";
            $car.= "</tr>";
         }
         $car.="</table></div>";
         $car .= $footer;
         $car .='</div>';
         $k++;
     }
     
     
     
     
     /**
      * 
      */

     //Last page
     $lastPage = '<div class="last_page">';
     $lastPage .= $header;
     $lastPage .= '<div class="horizontal_margin">
            <div class="ind_cntnt">
            
            <div id="contact_block">
            	<div id="cont_titlebg" class="bg_colorbase1">
                	<p style="font-size:16px; color:#ffffff; font-weight:bold; display:block; margin:8px 0px 0px 80px">Contact Us</p>
                </div>
                
               <div id="address">
                <h4 class="bold">Corporate Office:</h4>
                <h4 class="normal line_spacer">Career Breeder<br />
            C/O Oprotech Technologies Pvt. Ltd.<br />
            5/142, Awas Vikas Colony<br />
            Farrukhabad, Uttar Pradesh, India - 209625</h4><br />
             <h4 class="normal line_spacer">Mumbai:<br />
            ShriManoshi Complex, <br />
            Shop No.19, Plot No 5&amp;6,<br />
            Sector 3, Ghansoli<br />
            Navi Mumbai - 400701</h4><br />
             <h4 class="normal line_spacer">Email: contactus@careerbreeder.com<br />
            Tel: +91 97430 83301<br />
            Website: www.careerbreeder.com</h4>
            </div>
            
            <div id="did_youknow">
            <img src="wp-content/plugins/cb-test/result_scripts/cb_ci_images/did-you-know.png" width="43" height="45" style="float:left" />
            <h1 class="lftfloated normal" style="margin:8px 0px 0px 15px;">As part of a social responsibility, whenever you buy anything from us,<br />
            a part of it goes for Social Welfare.</h1>
            </div>
            </div>
            </div>
            </div>';
     $lastPage .= $footer;
     $lastPage .= "</div>";
     
     $end ='</body></html>';


    //Online Graph.
    /*
    $graphs = '<link class="include" rel="stylesheet" type="text/css" href="wp-content/plugins/cb-test/result_scripts/dist/jquery.jqplot.min.css" />
  <!--[if lt IE 9]><script language="javascript" type="text/javascript" src="wp-content/plugins/cb-test/result_scripts/dist/excanvas.js"></script><![endif]-->
    <script class="include" type="text/javascript" src="wp-content/plugins/cb-test/result_scripts/dist/jquery.min.js"></script>
    <!-- Dont touch this! -->
    <script class="include" type="text/javascript" src="wp-content/plugins/cb-test/result_scripts/dist/jquery.jqplot.min.js"></script>
<!-- End Dont touch this! -->
  <script class="include" type="text/javascript" src="wp-content/plugins/cb-test/result_scripts/dist/plugins/jqplot.pieRenderer.min.js"></script>
  <script class="include" type="text/javascript" src="wp-content/plugins/cb-test/result_scripts/dist/examples/example.min.js"></script>

    <div id="plot8" style="margin-top:20px; margin-left:20px; width:460px; height:300px;"></div>
    
    
<script class="code" type="text/javascript">
    var s1 = [[\'Extrovert\',7], [\'Introvert\',13.3]];
         
    var plot8 = $.jqplot(\'plot8\', [s1], {
        grid: {
            drawBorder: false, 
            drawGridlines: false,
            background: \'#ffffff\',
            shadow:false
        },
        axesDefaults: {
             
        },
        seriesDefaults:{
            renderer:$.jqplot.PieRenderer,
            rendererOptions: {
                showDataLabels: true,
                 dataLabels: \'label\'
            }
        },
        legend: {
            show: true,
            rendererOptions: {
                numberRows: 1
            },
            location: \'s\'
        }
    }); 
</script>';*/


  $res.= $description_page;
  $res.= $graphs;
  $res.= $sugg;
  $res.= $car;
  $res.= $lastPage;
  $res.= $end;

    //create PDF
    $dompdf = new DOMPDF();
    $dompdf->load_html($res);
    $dompdf->set_paper('a4','portrait' );
    $dompdf->render();
    $dompdf->stream("report.pdf", array("Attachment" => false));
/*    $fileName = "cbci".$ref_no.".pdf";
    $dompdf->stream("dompdf.php", array("Attachment" => false));
*/
  


        /*
        if($option_no == 0)
        {
            if(cb_test_helper123($answers[$section_no][$question_no-20*$section_no])==1)
                $res[$section_no]['a']++;
            else if(cb_test_helper123($answers[$section_no][$question_no-20*$section_no])==2)
                $res[$section_no]['b']++;
            else 
                echo "Something is wrong $section_no , $question_no";
        } else if($option_no == 1) {
            //just reverse the results :)
            if(cb_test_helper123($answers[$section_no][$question_no-20*$section_no])==2)
                $res[$section_no]['a']++;
            else if(cb_test_helper123($answers[$section_no][$question_no-20*$section_no])==1)
                $res[$section_no]['b']++; 
            else
                echo "Something is wrong $section_no , $question_no";
        } else {
            echo "Some error occured in Question Number $i,$option_no,$option_id,$section_no";
        }
        */
    //    if($answers[$question_no]['answer']==$option_no)
    //        $marksObtained += $answers[$question_no]['weight'];   
    
    //update_user_meta($user_id, 'dob', '10-01-1990');
    //echo $marksObtained;
    //algorithm to calculate score
    
    
    //Fet person's age from DOB
    //$dob = get_user_meta($user_id, 'dob');
    //$ageTime = strtotime($dob[0]); // Get the person's birthday timestamp
    //$t = time(); // Store current time for consistency
    //$age = ($ageTime < 0) ? ( $t + ($ageTime * -1) ) : $t - $ageTime;
    //$year = 60 * 60 * 24 * 365;
    //$ageYears = floor($age / $year);
    //
    //
    //$IQ = $marksObtained/$ageYears*100;
    //
    return $res;
}

function cb_test_helper123($char) {
    switch($char) {
        case 'P':
        case 'E':
        case 'D':
        case 'R':
        case 'Q':
                    return 0;
        case 'C':
        case 'M':
        case 'I':
        case 'F':
        case 'S':
                    return 1;
        default:
                    return 2;
    }
}

function cb_ci_characteristic($code)
{
    switch($code)
    {
        case 'C':
                $sug['title'] = 'Creative Thinking';
                $sug['characteristic'] ='<ul>
                          <li>These are people who always try new  and innovative solution for the problem.</li>
                          <li>Try to do things with perfection.</li>
                          <li>Have a quality to see the hidden  side of the problem.</li>
                          <li>Have a very good observation level.</li>
                          <li>Have a good power of visualization.</li>
                      </ul>';
                $sug['suggestion'] = '<ul>
                          <li>Avoid  multi tasking attitude.</li>
                          <li>Learn  money management. </li>
                          <li>Always  make priority chart when you work or study. </li>
                          <li>Don&prime;t  purchase too many things at once.</li>
                          <li>Study  biography of leaders like Mahatma Gandhi. </li>
                </ul>';
                return $sug;
        case 'P':
                $sug['title'] = 'Practical Thinking';
                $sug['characteristic'] ='<ul>
                      <li>These are people who will solve  problems with experiences and learning. </li>
                      <li>Always use present resources for  improvement.</li>
                      <li>They are always appreciated by  others for their hard work.</li>
                      <li>They are very good planners.</li>
                      <li>They are very good in money  management and money handling.</li>
                    </ul>';
                $sug['suggestion'] = '<ul>
                      <li>Listen  to classical music. </li>
                      <li>Join  hobby classes like drawing, singing, musical instruments, craft workshop, etc. </li>
                      <li>Whenever  you have a problem, first write it down on a paper and try to find as many solutions  as possible.</li>
                      <li>Learn  chucking phenomena for memorizing.</li>
                      <li>Learn  self hypnosis.</li>
                </ul>';
                return $sug;
        case 'D':
                $sug['title'] = 'Determinant';
                $sug['characteristic'] ='<ul>
                      <li>These are people who are very  organized. </li>
                      <li>Like to do work in systematic  manner. </li>
                      <li>Have a very strong analytical power.</li>
                      <li>They have good sense of their  priorities and their life goals.</li>
                      <li>Will always make decisions with the  help of realistic facts. </li>
                    </ul>';
                $sug['suggestion'] = '<ul>
                      <li>Always  respect your family &amp; social relationships.</li>
                      <li>Before  making a goal, consult your elders. </li>
                      <li>Always  make a backup plan for your work so if one fails, you have other.</li>
                      <li>Give  some time to social work or join any NGO and help others.</li>
                      <li>Make  a mentor for your life success.</li>
                </ul>';
                return $sug;
        case 'M':
                $sug['title'] = 'Moody';
                $sug['characteristic'] ='<ul>
                      <li>These are people who work according  to their own schedule.</li>
                      <li>Give preference to their emotion at  work.</li>
                      <li>They are very caring and get  respect in society. </li>
                      <li>They are good motivators.</li>
                      <li>They are socially well recognized and  have a huge contribution to the society.</li>
                    </ul>';
                $sug['suggestion'] = '<ul>
                      <li>Do  not deviate from your work plan. Be firm.</li>
                      <li>Always  make your work plan with the focus on the end result. </li>
                      <li>Always  consult with a successful person for your career suggestions.</li>
                      <li>Make  a routine or a day plan every day. </li>
                      <li>Learn  to say NO in life.</li>
                </ul>';
                return $sug;
        case 'E':
                $sug['title'] = 'Extrovert';
                $sug['characteristic'] ='<ul>
                          <li>These are people who are very  strong in communications.</li>
                          <li>They are team players and prefer to  work in groups.</li>
                          <li>They are generally called &ldquo;leaders&rdquo;.</li>
                          <li>Express their emotions very easily. </li>
                          <li>They are socially very active. </li>
                      </ul>';
                $sug['suggestion'] = '<ul>
                      <li>Right  down in a diary every day.</li>
                      <li>Make  a role model.</li>
                      <li>Always  try to listen to other people carefully.</li>
                      <li>Schedule  your whole day in the morning.</li>
                      <li>Do  some meditation &amp; relaxation exercises every day.</li>
                </ul>';
                return $sug;
        case 'I':
                $sug['title'] = 'Introvert';
                $sug['characteristic'] ='<ul>
                          <li>These are people who have limited  power to communicate.</li>
                          <li>Have good success rate when they work  alone.</li>
                          <li>Have strong understanding of the emotions  of others. </li>
                          <li>Give much time to thinking before  any work.</li>
                          <li>Rarely express emotions in public. </li>
                      </ul>';
                $sug['suggestion'] = '<ul>
                          <li>Learn  a new way to express your emotion.</li>
                          <li>Change  the color of the clothes. Wear bright colors.</li>
                          <li>Join  any health &amp; fitness center.</li>
                          <li>Avoid  virtual community (face book, Chatting).</li>
                          <li>Read  books like &lsquo;How to influence people &amp; friends&rsquo; by Dale Carnegie.</li>
                </ul>';
                return $sug;
        case 'Q':
                $sug['title'] = 'Quick decision maker';
                $sug['characteristic'] ='<ul>
                          <li>These are people who take decisions  on the spot.</li>
                          <li>Have low insecurity feeling. </li>
                          <li>Utilize opportunity very well.</li>
                          <li>They are generally called SMART.</li>
                          <li>Have good level of will power. </li>
                    </ul>';
                $sug['suggestion'] = '<ul>
                          <li>Always  consult with an expert whenever you plan a new work.</li>
                          <li>Never  take too many risks at once.</li>
                          <li>Always  review your work plan within a certain time limit.</li>
                          <li>Always  make a backup plan so if anything goes wrong you have options. </li>
                          <li>Make  a proper work plan with specific needs and results. </li>
                </ul>';
                return $sug;
        case 'S':
                $sug['title'] = 'Security minded';
                $sug['characteristic'] ='<ul>
                          <li>These are people who analyse things  and then take decisions. </li>
                          <li>They are emotionally very mature. </li>
                          <li>They are generally called visionaries.</li>
                          <li>Their planning and goal are perfect. </li>
                          <li>They are generally highly  successful.</li>
                    </ul>';
                $sug['suggestion'] = '<ul>
                          <li>Always  try to finish your work plan and your plan must have a fixed Time Line. </li>
                          <li>Join  adventure sports (river rafting, rock climbing).</li>
                          <li>Whatever  work you do give it your 100%.</li>
                          <li>Play  games like tennis, chess and/or horse riding. </li>
                          <li>Take  part in cultural activities. </li>
                </ul>';
                return $sug;
        case 'R':
                $sug['title'] = 'Rule bound';
                $sug['characteristic'] ='<ul>
                          <li>These are people who always complete their work  on time.</li>
                          <li>Always respect rules and follow them.</li>
                          <li>Work towards a goal and cannot be distracted easily.</li>
                          <li>Always fix a very high target point for them.</li>
                          <li>Have a near about fixed routine life.</li>
                    </ul>';
                $sug['suggestion'] = '<ul>
                          <li>No  work plan can be perfect. So be flexible and change your work plan when one  plan does not work.</li>
                          <li>Always  try to work in a group and help others in their work. </li>
                          <li>Develop  some hobbies to enjoy life. For example, learn music, dance etc. </li>
                          <li>Learn  some yoga techniques to manage your stress and relax. </li>
                </ul>';
                return $sug;
        case 'F':
                $sug['title'] = 'Flexible';
                $sug['characteristic'] ='<ul>
                          <li>These are people who simultaneously start multiple  works. </li>
                          <li>They are very adjustable in their environment. </li>
                          <li>They are called happy go lucky person.</li>
                          <li>Get bored easily so likes changes. </li>
                          <li>They  are slightly weak in time management.</li>
                    </ul>';
                $sug['suggestion'] = '<ul>
                          <li>Set  priorities and complete your target one by one.</li>
                          <li>Never  lose hope. First complete your work and then rest. </li>
                          <li>Read  biography of some great people like Mahatma Gandhi, Abraham Lincoln, Dhiru Bhai  Ambani etc.</li>
                          <li>Be  aggressive in your work.</li>
                          <li>Learn time management skills. </li>
                </ul>';
                return $sug;
    }
}


?>